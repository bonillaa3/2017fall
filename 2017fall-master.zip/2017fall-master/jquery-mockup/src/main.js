import 'bootstrap'
import './navigation.ts';
import './game.ts';
import './main.scss';
